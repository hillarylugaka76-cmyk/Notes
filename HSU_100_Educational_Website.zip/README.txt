HSU 100 LEARNING HUB
====================

HOW TO USE
1. Extract the ZIP file.
2. Open the extracted folder.
3. Open index.html in a modern web browser (Chrome, Edge, Firefox, etc.).
4. Browse, search, filter, read and download the included PDF resources.

CONTENTS
- index.html: Website structure
- styles.css: Website design and responsive layout
- script.js: Search, filters and PDF viewer
- pdfs/: The 10 supplied PDF documents

NOTES
- The website runs locally; no server or installation is required.
- Internet is only needed for the optional Google Fonts import. The website remains usable without it.
- PDF viewing depends on the browser's built-in PDF support. Use the Save button if a PDF does not preview.
